package com.example.request

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.request.database.User
import com.example.request.databinding.ItemPokemonBinding
import org.json.JSONObject


class MainAdapter(private val pokemones:Array<User>): RecyclerView.Adapter<MainAdapter.MainHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainAdapter.MainHolder {
        val binding = ItemPokemonBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MainHolder(binding)
    }

    override fun onBindViewHolder(holder: MainAdapter.MainHolder, position: Int) {
        holder.render(pokemones[position])
    }

    override fun getItemCount(): Int = pokemones.size

    class MainHolder(val binding: ItemPokemonBinding): RecyclerView.ViewHolder(binding.root){
        fun render(pokemon: User, position: Int){
            binding.tvPokemon.setText(""+ (position + 1) + ".- "+ pokemon.user_name)
        }

    }
}