package com.example.request.database

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import java.util.*

//TODO add TABLE_USERS constant
@Entity (tableName = TABLE_USERS)
data class UserEntity(
    @ColumnInfo(name = "user_id") @PrimaryKey val uuid: String,
    @ColumnInfo(name = "user_name") val name:String
)

fun UserEntity.toUser() = User(uuid, name)