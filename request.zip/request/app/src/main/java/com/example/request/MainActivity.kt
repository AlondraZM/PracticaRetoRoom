package com.example.request

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.viewModels
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.request.database.DatabaseManager
import com.example.request.database.User
import com.example.request.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject


class MainActivity : AppCompatActivity() {
    private val mainViewModel: MainViewModel by viewModels()
    private lateinit var queue: RequestQueue
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //ROOM
        //val userDao = DatabaseManager.instance.database.userDao()
        //val temp = userDao.getUsersFromDatabase()

        mainViewModel.getUsers()
        mainViewModel.savedUsers.observe(this, {usersList ->
            if(!usersList.isNullOrEmpty()){
                for (user in usersList){
                    Log.d("thesearetheusers", user.user_name)
                }
            }else{
                Log.d("thesearetheusers", "null or empty")
            }
        })



        val pokemones: Array<JSONObject>

        binding.btnUpdatePokemon.setOnClickListener{
            var num = binding.etPokemonAmount.text

            if(num.isEmpty()){
                Toast.makeText(this,"Nombre de usuario invalido", Toast.LENGTH_LONG).show()
            }else{
                mainViewModel.saveUser(User("00$num", "$num"))
                //queue = Volley.newRequestQueue(this)
                //getPokemonList(Integer.parseInt(num.toString()))
                listar()
            }
        }

    }
    fun listar() {

            mainViewModel.savedUsers.observe(this, {usersList ->

                var pokemones: Array<User>? = usersList.toTypedArray()
                binding.rvPokemonEntries.adapter = MainAdapter(pokemones)
            })


    }

    /*fun getPokemonList(listAmount: Int) {
        var url = "https://pokeapi.co/api/v2/pokemon/?limit=${listAmount}"


        val jsonRequest = JsonObjectRequest(url, Response.Listener<JSONObject>{response ->
            var pokemones:JSONArray = response.getJSONArray("results")
            binding.rvPokemonEntries.adapter = MainAdapter(pokemones)
        },
        Response.ErrorListener{ error ->
            Toast.makeText(this, "no se encontró ningun pokemon", Toast.LENGTH_LONG)
        })

        queue.add(jsonRequest)
    }**/

    override fun onStop() {
        super.onStop()
        queue.cancelAll("Stopped")
    }
}